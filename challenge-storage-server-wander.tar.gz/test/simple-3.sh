curl --request POST http://localhost:7777/store/blah --data-binary @../test/data.txt
curl http://localhost:7777/store/blah
curl --request DELETE http://localhost:7777/store/blah
