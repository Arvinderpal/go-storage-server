curl --request POST http://localhost:7777/store/foo --data "11111111111111111"
curl --request PUT http://localhost:7777/store/foo --data "22222222222222222"
curl http://localhost:7777/store/foo
curl --request DELETE http://localhost:7777/store/foo
